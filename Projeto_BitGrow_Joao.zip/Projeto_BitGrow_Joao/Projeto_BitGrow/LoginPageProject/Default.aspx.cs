﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Web.Services;
using System.Web.Script.Services;

namespace LoginPageProject
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]
        [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
        public static List<Pessoa> pa_ObterPessoas()
        {
            List<Pessoa> Pessoas = new List<Pessoa>();

            // Use the connection string from the configuration file
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand("pa_ObterPessoas", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Pessoa pessoa = new Pessoa
                            {
                                Id_Pessoa = Convert.ToInt32(reader["Id_Pessoa"]),
                                Nm_Pessoa = reader["Nm_Pessoa"].ToString(),
                                Dt_Cadastro = reader["Dt_Cadastro"].ToString(), // Verify the correct field name
                                Dt_Nascimento = reader["Dt_Nascimento"].ToString(),
                                Endereco = reader["Endereco"].ToString(),
                                Observacao = reader["Observacao"].ToString(),
                                Escolaridade = reader["Escolaridade"].ToString(),
                                Nm_Escola = reader["Nm_Escola"].ToString()
                            };

                            Pessoas.Add(pessoa);
                        }
                    }
                }
            }

            return Pessoas;
        }
    }
}
