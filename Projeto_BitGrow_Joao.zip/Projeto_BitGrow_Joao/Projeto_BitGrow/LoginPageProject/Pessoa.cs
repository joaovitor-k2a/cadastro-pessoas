﻿namespace LoginPageProject
{
    public class Pessoa
    {
        public int Id_Pessoa { get; set; }
        public string Nm_Pessoa { get; set; }
        public string Dt_Cadastro { get; set; }
        public string Dt_Nascimento { get; set; }
        public string Endereco { get; set; }
        public string Observacao { get; set; }
        public string Escolaridade { get; set; }
        public string Nm_Escola { get; set; }
    }
}
