using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace LoginPageProject
{
    public partial class GetData : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        [WebMethod]
        public static string FetchData()
        {
            // Replace with your actual database connection details
            string connectionString="Data Source=K2A-JOAOVITOR\\BITGROW;Initial Catalog=BitGrow;User ID=sa;Password=123;Integrated Security=False";
            List<Dictionary<string, object>> data = new List<Dictionary<string, object>>();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Replace with your actual SQL query
                    string query = "SELECT 
										   Id_Pessoa,
										   Nm_Pessoa, 
										   Dt_Cadastro, 
										   CEP,
										   Dt_Nascimento,
										   Endereco,
										   Observacao,
										   Escolaridade
										   Nm_Escola
										   FROM Pessoa";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                // Populate data dictionary with query results
                                Dictionary<string, object> row = new Dictionary<string, object>
                                {
                                    { "Id_Pessoa", reader["Id_Pessoa"] },
                                    { "Nm_Pessoa", reader["Nm_Pessoa"] },
                                    { "Dt_Cadastro", reader["Dt_Cadastro"] },
									{ "CEP", reader["CEP"] },
                                    { "Dt_Nascimento", reader["Dt_Nascimento"] },
                                    { "Endereco", reader["Endereco"] },
									{ "Observacao", reader["Observacao"] },
                                    { "Escolaridade", reader["Escolaridade"] },
                                    { "Nm_Escola", reader["Nm_Escola"] }
                                };
                                data.Add(row);
                            }
                        }
                    }
                }
            }
catch (Exception ex)
{
    // Handle database connection or query errors
    Console.WriteLine("Error: " + ex.Message);
    throw; // Rethrow the exception to indicate that an error occurred
}

